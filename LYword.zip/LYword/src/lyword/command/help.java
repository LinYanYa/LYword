package lyword.command;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class help implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender commandSender, Command command, String s, String[] strings) {
        Player p = (Player) commandSender;
        if (commandSender instanceof Player){
            if (strings.length == 0){
                p.sendTitle("§e§l--|[§b§l林言信息§e§l]|--", "§c§l感谢使用本插件,Thank uou!", 10, 70, 20);
                p.sendMessage(ChatColor.YELLOW + "林言综合信息插件>>>" + ChatColor.WHITE + "     By LinYan");
                p.sendMessage(ChatColor.BLUE + "/lyhelp - 查询插件帮助");
                p.sendMessage(ChatColor.BLUE + "/lyclear - 清屏");
                p.sendMessage(ChatColor.BLUE + "/lynotice <内容> - 喊话 (使用%%代替空格)");
                p.sendMessage(ChatColor.BLUE + "/lyreload - 重载插件配置");
                p.sendMessage(ChatColor.YELLOW + "感谢盆友们的支持!");
            }else {
                p.sendMessage(ChatColor.RED + "未知指令,输入/lyhelp查看帮助");
            }
        }else {
            System.out.println("该指令由玩家执行");
        }
        return false;
    }
}
