package lyword.command;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class clear implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender commandSender, Command command, String s, String[] strings) {
        Plugin plugin = lyword.lyword.getPlugin(lyword.lyword.class);
        String message = plugin.getConfig().getString("clear.message").replaceAll("&", "§");
        Player p = (Player) commandSender;
        Player onlineplayer;
        List<Player> online = new ArrayList();
        online.addAll(Bukkit.getServer().getOnlinePlayers());
        Iterator onlinep = online.iterator();
        onlineplayer = (Player)onlinep.next();
        if (commandSender instanceof Player){
            if (p.hasPermission("lyword.clear")){
                int i;
                for(i = 0; i < 50; ++i) {
                    onlineplayer.sendMessage(" ");
                }
                onlineplayer.sendMessage(message);
            }else {
                p.sendMessage(ChatColor.RED + "你没有权限!");
            }
        }else {
            System.out.println("该命令只能由玩家执行!");
        }
        return false;
    }
}
