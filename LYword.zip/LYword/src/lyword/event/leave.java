package lyword.event;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

public class leave implements Listener {
    @EventHandler
    public void leave (PlayerQuitEvent quitEvent){
        Player p = quitEvent.getPlayer();
        Plugin pl = lyword.lyword.getPlugin(lyword.lyword.class);
        String m = pl.getConfig().getString("jl.leave").replaceAll("%player%", p.getName());
        if (pl.getConfig().getBoolean("jl.enable")){
            quitEvent.setQuitMessage(m);
        }
    }
}
