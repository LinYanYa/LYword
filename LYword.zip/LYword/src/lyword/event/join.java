package lyword.event;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;

public class join implements Listener {
    @EventHandler
    public void join (PlayerJoinEvent joinEvent){
        Player p = joinEvent.getPlayer();
        Plugin pl = lyword.lyword.getPlugin(lyword.lyword.class);
        String m = pl.getConfig().getString("jl.join").replaceAll("%player%", p.getName());
        if (pl.getConfig().getBoolean("jl.enable")){
            joinEvent.setJoinMessage(m);
        }

    }
}
